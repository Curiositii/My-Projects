package com.example.demo.repositories;

import com.example.demo.domain.Dessert;
import org.springframework.data.repository.CrudRepository;

/**
 *
 *
 *
 *
 */
public interface DessertRepository extends CrudRepository<Dessert,Long> {
}
