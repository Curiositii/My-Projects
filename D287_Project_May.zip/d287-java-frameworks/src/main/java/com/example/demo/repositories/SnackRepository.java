package com.example.demo.repositories;

import com.example.demo.domain.Snack;
import org.springframework.data.repository.CrudRepository;

/**
 *
 *
 *
 *
 */
public interface SnackRepository extends CrudRepository<Snack,Long> {
}
